Cloned from: https://github.com/Filsh/PHP-Bounce-Handler @18-Oct-2016
