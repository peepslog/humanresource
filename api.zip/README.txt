For installation and upgrade instructions, please see: https://www.timetrex.com/how-to-install-timetrex
