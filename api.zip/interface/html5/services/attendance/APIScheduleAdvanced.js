var APIScheduleAdvanced = ServiceCaller.extend( {

	key_name: 'ScheduleAdvanced',
	className: 'APIScheduleAdvanced',

	getScheduleAvailableUsers: function() {

		return this.argumentsHandler( this.className, 'getScheduleAvailableUsers', arguments );

	}





} );