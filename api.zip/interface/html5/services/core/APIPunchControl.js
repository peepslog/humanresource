var APIPunchControl = ServiceCaller.extend( {

	key_name: 'PunchControl',
	className: 'APIPunchControl',

	dragNdropPunch: function() {

		return this.argumentsHandler( this.className, 'dragNdropPunch', arguments );

	}



} );