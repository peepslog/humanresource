;<?php die('Unauthorized Access...'); //SECURITY MECHANISM, DO NOT REMOVE//?>
;
;
; TimeTrex Configuration File
; *Linux* Example
;
;

;
; System paths. NO TRAILING SLASHES!
;
[path]
;URL to TimeTrex web root directory. ie: http://your.domain.com/<*BASE_URL*>
;DO NOT INCLUDE http://your.domain.com, just the directory AFTER your domain
base_url = "/interface/"

;
;Log directory  -- NOTICE: For security reasons, this should always be outside the web server document root.
;
log = "/home/softouch/data/log"

;
;Misc storage, for attachments/images -- NOTICE: For security reasons, this should always be outside the web server document root.
;
storage = "/home/softouch/data/storage"

;
;Full path and name to the PHP CLI Binary
;
php_cli = "/opt/cpanel/ea-php72/root/usr/bin/php"



;
; Database connection settings. These can be set from the installer.
;
[database]
type = postgres8

host = localhost
database_name = softouch_smarthr
user = softouch_slave
password = "ih#9vR6j9,K^"


;
; Email delivery settings.
;
[mail]
;Least setup, deliver email through TimeTrex's email relay via SOAP (HTTP port 80/443)

;Deliver email through remote SMTP server with the following settings.
delivery_method = soap, smtp
smtp_host = smtp.gmail.com
smtp_port = 587
smtp_username = erik.koslove@gmail.com
smtp_password = Jesus@peepslog234

;The domain that emails will be sent from, do not include the "@" or anything before it.
; *ONLY* specify this if "delivery_method" above is "smtp"
email_domain = softouch.cloud

;The local part of the email address that emails will be sent from, do not include the "@" or anything after it.
; *ONLY* specify this if "delivery_method" above is "smtp"
email_local_part = DoNotReply


;
; Cache settings
;
[cache]
enable = TRUE
;NOTICE: For security reasons, this must be outside the web server document root.
dir = "/home/softouch/data/timetrex"



[debug]
;Set to false if you're debugging
production = TRUE

enable = FALSE
enable_display = FALSE
buffer_output = TRUE
enable_log = FALSE
verbosity = 10



[other]
system_time_zone = "Africa/Abidjan"
uuid_seed = 4fe8d0d809a7
disable_google_analytics = TRUE
default_interface = html5



; Force all clients to use SSL.
force_ssl = TRUE
installer_enabled = FALSE
primary_company_id = 11e93264-271e-1470-bb85-4fe8d0d809a7

disable_powered_by_logo = TRUE
application_name = LUCKY

;Specify the URL hostname to be used to access TimeTrex. The BASE_URL specified above will be appended on to this automatically.
; This should be a fully qualified domain name only, do not include http:// or any trailing directories.
hostname = hr.softouch.cloud

;ONLY when using a fully qualified hostname specified above, enable CSRF validation for increased security.
enable_csrf_validation = TRUE

; System Administrators Email address to send critical errors to if necessary. Set to FALSE to disable completely.
;system_admin_email = kelvin.kalu@gmail.com

;WARNING: DO NOT CHANGE THIS AFTER YOU HAVE INSTALLED TIMETREX.
;If you do it will cause all your passwords to become invalid,
;and you may lose access to some encrypted data.
salt = 8a932c2190bf614aee29a7ea8b190888




