<div id="bottomContainer" class="bottom-container">
	<div class="footer">
		<div class="container">
			<div class="row">
				<div class="col-md-12 col-sm-12 col-xs-12">
					<p class="footer-copyright"><?php echo 'Copyright ©️2015 SmartHR. All Rights Reserved' ?></p>
				</div>
			</div>
		</div>
	</div>
</div>
<div id="overlay" class=""></div>
</body>

</html>
<?php
Debug::writeToLog();
?>